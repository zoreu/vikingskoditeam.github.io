# -*- coding: utf-8 -*-
from kodi_six import xbmcaddon

def localize(id):
    localize = xbmcaddon.Addon().getLocalizedString(id)
    return localize
    
def id(name):
    languages = {
    'movies': localize(32002),
    'tv_shows': localize(32003),
    'premiere': localize(32004),
    'trending': localize(32005),
    'next': localize(32006),
    'of': localize(32007),
    'please_wait': localize(32008),
    'looking_for_links': localize(32009),
    'no_stream_available': localize(32010),
    'enter_search': localize(32011),
    'search': localize(32012),
    'premiere2': localize(32013),
    'new_episodes': localize(32014),
    'live_tv': localize(32015),
    'no_playlist_available': localize(32016),
    'animes': localize(32017),
    'animes_list': localize(32018),
    'language': localize(32019),
    'portuguese': localize(32020),
    'next_page': localize(32021),
    'previous_page': localize(32022),
    'last_page': localize(32023),
    'nothing_found': localize(32024),
    'resolving_link': localize(32025),
    'tools': localize(32026),
    'settings': localize(32027)
    }
    if name in languages:
        translate = languages[name]
    else:
        translate = 'Invalid Name'        
    return translate
