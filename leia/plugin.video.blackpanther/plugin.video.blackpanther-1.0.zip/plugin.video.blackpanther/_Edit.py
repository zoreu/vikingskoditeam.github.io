import xbmcaddon

MainBase = ''
addon = xbmcaddon.Addon('plugin.video.blackpanther')
